package com.example.aarushisinghal.multilanguage;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioButton;

public class Sgame1 extends AppCompatActivity {
    ImageView i;
    RadioButton r1, r2;
    ImageButton b;
    int count;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_sgame1);
        b=(ImageButton)findViewById (R.id.b);
        i=(ImageView)findViewById (R.id.i);
        r1=(RadioButton)findViewById (R.id.r1);
        r2=(RadioButton)findViewById (R.id.r2);
        r1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener () {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)
                    count++;
                r2.setEnabled (false);
                r1.setEnabled (false);

            }


        });

        r2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener () {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)
                    r2.setEnabled (false);
                r1.setEnabled (false);
            }


        });
        b.setOnClickListener (new View.OnClickListener ( ) {

            @Override
            public void onClick(View v) {
                Intent mIntent = getIntent();
                Intent myIntent=new Intent (Sgame1.this,Sgame2.class);
                myIntent.putExtra("count",count);
                startActivity(myIntent);
            }

        });

    }
    }

