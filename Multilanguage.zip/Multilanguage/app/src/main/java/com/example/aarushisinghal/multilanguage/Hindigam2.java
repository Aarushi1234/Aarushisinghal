package com.example.aarushisinghal.multilanguage;

import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

public class Hindigam2 extends AppCompatActivity {
    ImageView i;
    MediaPlayer player;
    ImageButton b1;
    RadioButton r1, r2,r3;
    Button b,b2;
    TextView t3;
    int count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        player = MediaPlayer.create(this, R.raw.tamatar);
        player.setLooping(true); // Set looping
        player.setVolume(100,100);
        setContentView (R.layout.activity_hindigam2);
        b=(Button)findViewById (R.id.b);
        b1=(ImageButton)findViewById (R.id.b1);
        i=(ImageView)findViewById (R.id.i);
        r1=(RadioButton)findViewById (R.id.r1);
        r2=(RadioButton)findViewById (R.id.r2);
        r3=(RadioButton)findViewById (R.id.r3);
        t3=(TextView)findViewById (R.id.t2);
        i.setOnClickListener(new View.OnClickListener (){

            @Override
            public void onClick(View v) {
                player.start();

            }

        });
        r2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener () {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)
                    count++;
                r2.setEnabled (false);
                r1.setEnabled (false);
                r3.setEnabled (false);
                if(player.isPlaying ())
                {
                    player.stop ();
                }
            }
        });
        r1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener () {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)
                    r2.setEnabled (false);
                r1.setEnabled (false);
                r3.setEnabled (false);
                if(player.isPlaying ())
                {
                    player.stop ();
                }
            }
        });
        r3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener () {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)
                    r2.setEnabled (false);
                r1.setEnabled (false);
                r3.setEnabled (false);
                if(player.isPlaying ())
                {
                    player.stop ();
                }
            }
        });
        b.setOnClickListener (new View.OnClickListener ( ) {
            @Override
            public void onClick(View v) {
                if(player.isPlaying ())
                {
                    player.stop ();
                }
                Intent mIntent = getIntent();
                Bundle bundle=getIntent ().getExtras ();
                int value= (int)bundle.get("count");
                int total=value+count;
                if(total>2)
                {
                    t3.setText ("Your SCORE IS  "+total+"  LITTLE EINSTEIN");
                }
                else
                {
                    t3.setText ("Your SCORE IS  "+total+"  GOOD CHAP");
                }

            }
        });
        b1.setOnClickListener (new View.OnClickListener ( ) {
            @Override
            public void onClick(View v) {
                if(player.isPlaying ())
                {
                    player.stop ();
                }
                startActivity(new Intent (Hindigam2.this, Menu.class));

            }
        });
    }
}
