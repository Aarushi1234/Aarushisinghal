package com.example.aarushisinghal.multilanguage;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class profile extends AppCompatActivity {
    TextView tv1, tv2, tv3,tv;
    EditText e1, e2, e3;
    Button b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_profile);
        tv=(TextView)findViewById (R.id.tx);
        tv1=(TextView)findViewById (R.id.tv1);
        tv2=(TextView)findViewById (R.id.tv2);
        tv3=(TextView)findViewById (R.id.tv3);
        e1=(EditText) findViewById (R.id.e1);
        e2=(EditText) findViewById (R.id.e2);
        e3=(EditText)findViewById (R.id.e3);
        b=(Button)findViewById (R.id.b);
        b.setOnClickListener(new View.OnClickListener (){
            @Override
            public void onClick(View v) {
                String name=e1.getText ().toString ();
                String email=e2.getText ().toString ();
                String password=e3.getText ().toString ();
                if(name.equals ("")||email.equals ("")||password.equals (""))
                {
                    tv.setText ("FIELDS UNFILLED");
                }
                if(!(name.equals ("")||email.equals ("")||password.equals ("")))
                {
                    if( android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()==true)
                    {
                        tv.setText ("DATA SUCCESSFULLY UPDATED");
                    }
                    else{
                        tv.setText ("EMAIL IS NOT VALID");
                    }
                }

            }
        });

    }
}
