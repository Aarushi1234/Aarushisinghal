package com.example.aarushisinghal.multilanguage;

import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class Word2 extends AppCompatActivity {
ImageView i;
TextView tv;
ImageButton b;
    MediaPlayer player;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_word2);
        player = MediaPlayer.create(this, R.raw.khargosh);
        player.setLooping(true); // Set looping
        player.setVolume(100,100);
    tv= (TextView)findViewById (R.id.t);
    b=(ImageButton)findViewById (R.id.b);
        i=(ImageView)findViewById (R.id.i);
        i.setOnClickListener(new View.OnClickListener (){

            @Override
            public void onClick(View v) {
                player.start();

            }

        });
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(player.isPlaying ())
                {
                    player.stop ();
                }
                startActivity(new Intent(Word2.this, cat.class));
            }
        });
    }
}
