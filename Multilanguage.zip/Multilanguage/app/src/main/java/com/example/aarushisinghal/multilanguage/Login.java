package com.example.aarushisinghal.multilanguage;

import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Login extends AppCompatActivity {
TextView tv1, tv,t;

Button b,b2;
EditText ed, et2;
    MediaPlayer player;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        player = MediaPlayer.create(this, R.raw.kidsmusic);
        player.setLooping(true); // Set looping
        player.setVolume(100,100);
        setContentView (R.layout.activity_login);
        tv1= (TextView)findViewById (R.id.tv1);
        tv= (TextView)findViewById (R.id.tv1);
        ed= (EditText) findViewById (R.id.ed);
        et2= (EditText) findViewById (R.id.et2);
        b= (Button)findViewById (R.id.b);
        b2= (Button)findViewById (R.id.b2);
        t= (TextView)findViewById (R.id.t4);
        b.setOnClickListener(new View.OnClickListener () {
            @Override
            public void onClick(View v) {

                String id= ed.getText ().toString ();
                String pass=et2.getText ().toString ();
                if(id.equals ("")|| pass.equals (""))
                {
                    t.setText ("FILL THE CONTENTS ");
                }
                if(!(id.equals ("")&& pass.equals ("")))
                {
                    if(id.equals(pass))
                    {
                        startActivity(new Intent (Login.this, Menu.class));

                    }
                    else
                    {
                       t.setText ("LOGIN UNSUCCESSFUL ");
                    }}
              // player.start ();
                }
                //startActivity(new Intent (Login.this, Menu.class));

        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Login.this, profile.class));
            }
        });

    }
}
