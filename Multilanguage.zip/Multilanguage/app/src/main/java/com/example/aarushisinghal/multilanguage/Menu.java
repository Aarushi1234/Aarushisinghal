package com.example.aarushisinghal.multilanguage;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

public class Menu extends Activity{
ListView lv1;
TextView tv1;
String [] a={ "HINDI","SPANISH","GERMAN"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);

        setContentView (R.layout.activity_menu);
        lv1= (ListView)findViewById (R.id.lv1);
        tv1=(TextView)findViewById (R.id.tv1);
        ArrayAdapter adapter = new ArrayAdapter<String>(this,android.R.layout.simple_expandable_list_item_1,a);
        lv1.setAdapter (adapter);

        lv1.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> adapter, View view, int position, long arg) {

                if (position == 0) {
                    Intent appInfo = new Intent (Menu.this, Hindimenu.class);
                    startActivity (appInfo);

                } else if (position == 1) {
                    Intent appInfo = new Intent (Menu.this, Spanishmenu.class);
                    startActivity (appInfo);
                }
                else if (position == 2) {
                    Intent appInfo = new Intent (Menu.this, germanmenu.class);
                    startActivity (appInfo);


                }


            }
});

}

}