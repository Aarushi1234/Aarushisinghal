package com.example.aarushisinghal.multilanguage;

import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class Spanish extends AppCompatActivity {
    ImageButton b;
MediaPlayer player;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        player = MediaPlayer.create(this, R.raw.buddy);
        player.setLooping(true); // Set looping
        player.setVolume(100,100);
        setContentView (R.layout.activity_spanish);
        b=(ImageButton)findViewById (R.id.b);

        b.setOnClickListener(new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                startActivity(new Intent (Spanish.this, spanishbasics.class));
                //player.start ();

            }
        });
        //Intent svc=new Intent(this, Soundspan.class);
        //startService(svc);
    }

}
