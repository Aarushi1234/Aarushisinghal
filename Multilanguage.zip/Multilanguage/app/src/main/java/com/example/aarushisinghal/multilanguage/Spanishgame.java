package com.example.aarushisinghal.multilanguage;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class Spanishgame extends AppCompatActivity {
    TextView tv;
    ImageView im, im2;
    Button b;
    EditText e1, e2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_spanishgame2);
        im=(ImageView)findViewById (R.id.im2);
        im2= (ImageView)findViewById (R.id.im2);
        tv=(TextView)findViewById (R.id.tv);
        b=(Button)findViewById (R.id.b);
        e1=(EditText) findViewById (R.id.e1);
        e2=(EditText) findViewById (R.id.e2);
        b.setOnClickListener(new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                String j= e1.getText ().toString ();
                String h=e2.getText ().toString ();
                int count =0;
                if(j.equals ("Sello")||j.equals ("sello")||j.equals ("SELLO"))
                {
                    count++;
                }
                if(h.equals ("ÁRBOL")||h.equals ("Árbol")||h.equals ("árbol"))
                {
                    count++;
                }
                Intent myIntent=new Intent (Spanishgame.this,Spnishnext.class);
                myIntent.putExtra("count",count);
                startActivity(myIntent);
            }
        });
    }
}
