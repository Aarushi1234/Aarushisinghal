package com.example.aarushisinghal.multilanguage;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class Words1 extends AppCompatActivity {
    ImageButton b;
    ImageView im;
    TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_words1);
        b=(ImageButton)findViewById (R.id.b);
        im=(ImageView)findViewById (R.id.i);
        tv=(TextView)findViewById (R.id.tv);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent (Words1.this, ta.class));
            }
        });
    }
}
