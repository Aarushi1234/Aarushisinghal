package com.example.aarushisinghal.multilanguage;

import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class spanishbasics extends AppCompatActivity {
 ImageView i;
 TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_spanishbasics);
        tv= (TextView)findViewById (R.id.tv);
        i=(ImageView)findViewById (R.id.i2);
        i.setOnClickListener(new View.OnClickListener (){

            @Override
            public void onClick(View v) {

                startActivity(new Intent (spanishbasics.this, sbasicsmenu.class));
            }

        });
    }
}
