package com.example.aarushisinghal.multilanguage;

import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class HINDI extends AppCompatActivity {
TextView t;
ImageButton b;
MediaPlayer player;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_hindi);
        player = MediaPlayer.create(this, R.raw.anewbeginning);
        player.setLooping(true); // Set looping
        player.setVolume(100,100);

        b=(ImageButton)findViewById (R.id.b);
        t=(TextView)findViewById (R.id.t4);
        b.setOnClickListener(new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                startActivity(new Intent (HINDI.this, Swar.class));

               // player.start();


            }
        });

    }
}
