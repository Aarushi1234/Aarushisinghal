package com.example.aarushisinghal.multilanguage;

import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.TextView;

public class picturequiz extends AppCompatActivity {
    ImageButton b,b1;
    TextView t;
    MediaPlayer player;
    RadioButton r1,r2;
    int count1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_picturequiz);
        player = MediaPlayer.create(this, R.raw.bhalu);
        player.setLooping(true); // Set looping
        player.setVolume(100,100);
        r1=(RadioButton)findViewById (R.id.r1);
        r2=(RadioButton)findViewById (R.id.r2);
        t=(TextView)findViewById (R.id.t);
        b=(ImageButton)findViewById (R.id.b);
        b1=(ImageButton)findViewById (R.id.b1);
        r1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener () {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)
                 count1++;
                r2.setEnabled (false);
                r1.setEnabled (false);
                if(player.isPlaying ())
                {
                    player.stop ();
                }
                //t.setText ("CORRECT ANSWER");

            }


        });

        r2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener () {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)

                r2.setEnabled (false);
                r1.setEnabled (false);
                if(player.isPlaying ())
                {
                    player.stop ();
                }

                //t.setText ("WRONG ANSWER");

            }


        });
        b.setOnClickListener (new View.OnClickListener ( ) {

            @Override
            public void onClick(View v) {
                player.start ();
            }

        });
        b1.setOnClickListener (new View.OnClickListener ( ) {

            @Override
            public void onClick(View v) {
                if(player.isPlaying ())
                {
                    player.stop ();
                }
                Intent myIntent=new Intent (picturequiz.this,Hindigame1.class);
                Intent mIntent = getIntent();

                myIntent.putExtra("count1",count1);
                startActivity(myIntent);
                startActivity(myIntent);

            }

        });
    }
    }

