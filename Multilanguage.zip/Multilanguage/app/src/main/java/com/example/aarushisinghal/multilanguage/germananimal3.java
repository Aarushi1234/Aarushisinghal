package com.example.aarushisinghal.multilanguage;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class germananimal3 extends AppCompatActivity {
    ImageView i;
    TextView t,t2;
    ImageButton b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_germananimal3);
        b=(ImageButton)findViewById (R.id.b);
        t=(TextView)findViewById (R.id.t4);
        t2=(TextView)findViewById (R.id.t2);
        i=(ImageView)findViewById (R.id.i);
        b.setOnClickListener(new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                startActivity(new Intent (germananimal3.this, gbasicsmenu.class));

            }
        });
    }
}
