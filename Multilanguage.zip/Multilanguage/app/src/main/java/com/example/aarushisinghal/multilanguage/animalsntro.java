package com.example.aarushisinghal.multilanguage;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.Animation.AnimationListener;

public class animalsntro extends AppCompatActivity {
    ImageView i;
    TextView t;
    private Animation animFade;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_animalsntro);




        animFade = AnimationUtils.loadAnimation(this, R.anim.fadeout);
        t= (TextView)findViewById (R.id.t4);
        i=(ImageView)findViewById (R.id.b);
        i.setOnClickListener(new View.OnClickListener (){

            @Override
            public void onClick(View v) {
                animFade.setAnimationListener(new AnimationListener() {
                    public void onAnimationStart(Animation animation) {}
                    public void onAnimationRepeat(Animation animation) {}
                    public void onAnimationEnd(Animation animation) {
                        

                    }
                });
                startActivity(new Intent (animalsntro.this, Animals.class));


            }

        });
        i.startAnimation(animFade);

    }
}
