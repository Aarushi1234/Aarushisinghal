package com.example.aarushisinghal.multilanguage;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

public class spanishfruits extends AppCompatActivity {
TextView t2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_spanishfruits);
        t2=(TextView)findViewById (R.id.t2);
        Animation animation = AnimationUtils.loadAnimation(this,R.anim.scale);

        animation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                t2.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                Intent it  = new Intent(spanishfruits.this, spanish2w.class);
                startActivity(it);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

        t2.startAnimation(animation);

    }
}

