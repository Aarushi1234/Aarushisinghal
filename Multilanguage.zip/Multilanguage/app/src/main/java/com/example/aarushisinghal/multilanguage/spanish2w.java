package com.example.aarushisinghal.multilanguage;

import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class spanish2w extends AppCompatActivity {
    ImageButton b;
    ImageView i,i2;
    TextView t,t2,t3,t4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_spanish2w);
        b=(ImageButton)findViewById (R.id.b);
        i=(ImageView)findViewById (R.id.i);
        i2=(ImageView)findViewById (R.id.i2);
        t=(TextView)findViewById (R.id.t);
        t2=(TextView)findViewById (R.id.t2);
        t3=(TextView)findViewById (R.id.t1);
        t4=(TextView)findViewById (R.id.t4);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent (spanish2w.this , spanishfruits2.class));
            }
        });
    }
}
