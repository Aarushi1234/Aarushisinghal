package com.example.aarushisinghal.multilanguage;

import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class Germanwords extends AppCompatActivity {
    ImageButton b;
    ImageView i,i2;
    TextView t5,t6;
    MediaPlayer player;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_germanwords);
        b=(ImageButton)findViewById (R.id.b);
        i2=(ImageView)findViewById (R.id.i2);
        t5=(TextView)findViewById (R.id.t5);
        t6=(TextView)findViewById (R.id.t6);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent (Germanwords.this , germanwords2.class));
            }
        });
    }
}
