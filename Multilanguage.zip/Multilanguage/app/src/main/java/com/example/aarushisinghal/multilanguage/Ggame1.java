package com.example.aarushisinghal.multilanguage;

import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioButton;

public class Ggame1 extends AppCompatActivity {
    ImageView i;
    RadioButton r1, r2,r3;
    ImageButton b;
    MediaPlayer player;


    int count;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_ggame1);
        b=(ImageButton)findViewById (R.id.b);

        i=(ImageView)findViewById (R.id.imageView5);
        r1=(RadioButton)findViewById (R.id.r1);
        r2=(RadioButton)findViewById (R.id.r2);
        r3=(RadioButton)findViewById (R.id.r3);
        r1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener () {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)
                    count++;
                r2.setEnabled (false);
                r1.setEnabled (false);
                r3.setEnabled (false);

            }


        });

        r2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener () {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)

                    r2.setEnabled (false);
                r1.setEnabled (false);
                r3.setEnabled (false);

            }


        });
        r3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener () {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)
                    r2.setEnabled (false);
                r1.setEnabled (false);
                r3.setEnabled (false);

            }


        });
        b.setOnClickListener (new View.OnClickListener ( ) {

            @Override
            public void onClick(View v) {

                Intent myIntent=new Intent (Ggame1.this,Ggame2.class);
                myIntent.putExtra("count",count);
                startActivity(myIntent);
            }

        });
    }
}
