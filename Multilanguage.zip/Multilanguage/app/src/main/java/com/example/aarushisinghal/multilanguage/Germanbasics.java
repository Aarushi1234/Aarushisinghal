package com.example.aarushisinghal.multilanguage;

import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class Germanbasics extends AppCompatActivity {
ImageView i;
TextView t;
MediaPlayer player;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        player = MediaPlayer.create(this, R.raw.ukele);
        player.setLooping(true); // Set looping
        player.setVolume(100,100);
        setContentView (R.layout.activity_germanbasics);
        t=(TextView)findViewById (R.id.t4);
        i=(ImageView)findViewById (R.id.i2);
        i.setOnClickListener(new View.OnClickListener (){

            @Override
            public void onClick(View v) {
               
                startActivity(new Intent (Germanbasics.this, gbasicsmenu.class));


            }

        });
       // Intent svc=new Intent(this, sound.class);
       // startService(svc);
    }
}
