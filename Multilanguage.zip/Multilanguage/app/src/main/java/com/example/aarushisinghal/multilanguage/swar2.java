package com.example.aarushisinghal.multilanguage;

import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class swar2 extends AppCompatActivity {
    ImageButton b,b1,b2;
    MediaPlayer player;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_swar2);
        player = MediaPlayer.create(this, R.raw.aaihindi);
        player.setLooping(true); // Set looping
        player.setVolume(100,100);
        b=(ImageButton)findViewById (R.id.b);
        b1=(ImageButton)findViewById (R.id.b1);
        b2=(ImageButton)findViewById (R.id.b2);
        b.setOnClickListener(new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                player.start ();

            }
        });
        b1.setOnClickListener(new View.OnClickListener () {
            @Override
            public void onClick(View v) {

                if(player.isPlaying ())
                {
                    player.stop ();
                }
                startActivity(new Intent (swar2.this, Swar.class));

            }
        });
        b2.setOnClickListener(new View.OnClickListener () {
            @Override
            public void onClick(View v) {

                if(player.isPlaying ())
                {
                    player.stop ();
                }

                startActivity(new Intent (swar2.this, basicshindimenu.class));

            }
        });

    }
}
