package com.example.aarushisinghal.multilanguage;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class germanmenu extends AppCompatActivity {
    ListView lv1;

    String [] a={ "BASICS","QUIZ"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_germanmenu);
        lv1= (ListView)findViewById (R.id.lv1);

        ArrayAdapter adapter = new ArrayAdapter<String>(this,android.R.layout.simple_expandable_list_item_1,a);
        lv1.setAdapter (adapter);

        lv1.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> adapter, View view, int position, long arg) {

                if (position == 0) {
                    Intent appInfo = new Intent (germanmenu.this, gbasicsmenu.class);
                    startActivity (appInfo);
                } else if (position == 1) {
                    Intent appInfo = new Intent (germanmenu.this, Ggame1.class);
                    startActivity (appInfo);
                }
            }
        });

    }
}
