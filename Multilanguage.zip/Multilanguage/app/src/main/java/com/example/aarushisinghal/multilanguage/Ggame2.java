package com.example.aarushisinghal.multilanguage;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

public class Ggame2 extends AppCompatActivity {
    ImageView i;
    ImageButton b1;
    RadioButton r1, r2,r3;
    TextView t3;
    Button b,b2;
    int count;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_ggame2);
        b=(Button)findViewById (R.id.b);
        b1=(ImageButton)findViewById (R.id.b1);
        i=(ImageView)findViewById (R.id.i);
        r1=(RadioButton)findViewById (R.id.r1);
        r2=(RadioButton)findViewById (R.id.r2);
        r3=(RadioButton)findViewById (R.id.r3);
        t3=(TextView)findViewById (R.id.t2);

        r2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener () {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)

                r2.setEnabled (false);
                r1.setEnabled (false);
                r3.setEnabled (false);
            }
        });
        r1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener () {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if(isChecked)
                    count++;
                    r2.setEnabled (false);
                r1.setEnabled (false);
                r3.setEnabled (false);
            }
        });
        r3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener () {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)
                    r2.setEnabled (false);
                r1.setEnabled (false);
                r3.setEnabled (false);
            }
        });
        b.setOnClickListener (new View.OnClickListener ( ) {
            @Override
            public void onClick(View v) {
                Intent mIntent = getIntent();
                Bundle bundle=getIntent ().getExtras ();
                int value= (int)bundle.get("count");
                int total=value+count;
                t3.setText ("Your SCORE IS   "+total);
            }
        });
        b1.setOnClickListener (new View.OnClickListener ( ) {
            @Override
            public void onClick(View v) {

                        startActivity(new Intent (Ggame2.this, Menu.class));
            }
        });
    }
}
